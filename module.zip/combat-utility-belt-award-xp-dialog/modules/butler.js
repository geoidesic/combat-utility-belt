import { EnhancedConditions } from "./enhanced-conditions/enhanced-conditions.js";
import { MightySummoner } from "./mighty-summoner.js";

export const NAME = "combat-utility-belt";

export const TITLE = "Combat Utility Belt";

export const SHORTNAME = "cub";

export const PATH = "modules/combat-utility-belt";

export const WIKIPATH = "https://github.com/death-save/combat-utility-belt/wiki"

export const GADGETS = {
    giveXP: {
        name: "Award XP",
        info: "Provides an end of combat prompt to distribute XP from defeated hostile combatants.",
        wiki: `${WIKIPATH}/award-xp`
    },
    concentrator: {
        name: "Concentrator",
        info: "Manages Concentration in the dnd5e game system.",
        wiki: `${WIKIPATH}/award-xp`
    },
    enhancedConditions: {
        name: "Enhanced Conditions",
        info: "Provides the ability to map Conditions to Status Effect icons",
        wiki: `${WIKIPATH}/enhanced-conditions`
    },
    hideNames: {
        name: "Hide Names",
        info: "Replaces Actor names with a new name of your choice",
        wiki: `${WIKIPATH}/hide-names`
    },
    panSelect: {
        name: "Pan/Select",
        info: "Automatic panning and selection of tokens during combat",
        wiki: `${WIKIPATH}/pan-select`
    },
    rerollInitiative: {
        name: "Reroll Initiative",
        info: "Rerolls Initiative on each Combat round change",
        wiki: `${WIKIPATH}/reroll-initiative`
    },
    tempCombatants: {
        name: "Temporary Combatants",
        info: "Allows the creation of temporary combatants to track things like environmental or lair actions",
        wiki: `${WIKIPATH}/temporary-combatants`
    },
    triggler: {
        name: "Triggler",
        info: "A trigger-management system for token/actor attribute changes",
        wiki: `${WIKIPATH}/triggler`
    },
    actorUtility: {
        name: "Misc Actor",
        info: "Miscellaneous Actor enhancements",
        wiki: `${WIKIPATH}/actor-misc`
    },
    tokenUtility: {
        name: "Misc Token",
        info: "Miscellaneous Token enhancements",
        wiki: null
    }
}
/**
 * Stores information about well known game systems. All other systems will resolve to "other"
 */
export const KNOWN_GAME_SYSTEMS = {
    dnd5e: {
        id: "dnd5e",
        name: "Dungeons & Dragons 5th Edition",
        concentrationAttribute: "con",
        healthAttribute: "attributes.hp",
        initiative: "attributes.initiative"
    },
    pf1: {
        id: "pf1",
        name: "Pathfinder",
        concentrationAttribute: "",
        healthAttribute: "attributes.hp",
        initiative: "attributes.init.total"
    },
    pf2e: {
        id: "pf2e",
        name: "Pathfinder 2nd Edition",
        concentrationAttribute: "",
        healthAttribute: "attributes.hp",
        initiative: "attributes.perception"
    },
    wfrp4e: {
        id: "wfrp4e",
        name: "Warhammer Fantasy Roleplaying Game 4th Edition",
        concentrationAttribute: "",
        healthAttribute: "status.wounds",
        initiative: "characteristics.i"
    },
    archmage: {
        id: "archmage",
        name: "13th Age",
        concentrationAttribute: "",
        healthAttribute: "attributes.hp",
        initiative: "attributes.init.mod"
    },
    other: {
        id: "other",
        name: "Custom/Other",
        concentrationAttribute: "--Unknown--",
        healthAttribute: "--Unknown--",
        initiative: "--Unknown--"
    }
} 
     
export const HEALTH_STATES = {
    HEALTHY: "healthy",
    INJURED: "injured",
    DEAD: "dead",
    UNCONSCIOUS: "unconscious"
}

export const DEFAULT_CONFIG = {
    aboutApp: {
        title: "About Combat Utility Belt"
    },
    concentrator: {
        conditionName: "Concentrating",
        enable: false,
        outputChat: false,
        promptRoll: false,
        autoConcentrate: false,
        notifyDouble: {
            none: "None",
            gm: "GM Only",
            all: "Everyone"
        },
        icon: "modules/combat-utility-belt/icons/concentrating.svg",
        alias: "Concentrator"
    },
    cubPuter: {
        id: "cub-puter",
        title: "CUBPuter",
        buttonId: "cub-puter-button",
        config: {
            crt: true,
            terminal: false,
            startup: false,
            greeting: false,
            instructions: false,
            info: true
        }
    },
    enhancedConditions: {
        iconPath: `${PATH}/icons/`,
        conditionMapsPath: `${PATH}/condition-maps`,
        outputChat: false,
        outputCombat: false,
        removeDefaultEffects: false,
        conditionLab: {
            id: "cub-condition-lab",
            title: "Condition Lab",
        },
        title: "Enhanced Conditions",
        mapTypes: {
            default: "System - Default",
            custom: "System - Custom",
            other: "Other/Imported"
        },
        referenceTypes: [
            {
                id: "journalEntry",
                name: "Journal",
                icon: `fas fa-book-open`
            },
            {
                id: "compendium.journalEntry",
                name: "Journal (C)",
                icon: `fas fa-atlas`
            },
            {
                id: "item",
                name: "Item",
                icon: `fas fa-suitcase`
            },
            {
                id: "compendium.item",
                name: "Item (C)",
                icon: `fas fa-suitcase`
            }
        ],
        templates: {
            conditionLab: `${PATH}/templates/condition-lab.hbs`,
            chatOutput: `${PATH}/templates/chat-conditions.hbs`,
            importDialog: `${PATH}/templates/import-conditions.html`
        }
    },
    giveXP: {
        enable: false,
        modifier: 1
    },
    hideNames: {
        enable: false,
        enableHostile: false,
        enableNeutral: false,
        enableFriendly: false,
        hideFooter: false,
        hideNameParts: false,
        hostileNameReplacement: "Unknown Creature",
        neutralNameReplacement: "Unknown Creature",
        friendlyNameReplacement: "Unknown Creature",
        hostileIcon: "far fa-angry",
        neutralIcon: "far fa-meh",
        friendlyIcon: "far fa-smile",
        actorForm: {
            id: "hide-names-actor",
            title: "Hide Name"
        }
    },
    injuredDead: {
        enableInjured: false,
        enableDead: false,
        enableUnconscious: false,
        injuredIcon: "icons/svg/blood.svg",
        threshold: 50,
        deadIcon: "icons/svg/skull.svg",
        markDefeated: false,
        unconsciousActorType: "",
        unconsciousIcon: "icons/svg/unconscious.svg"
    },
    mightySummoner: {
        enable: false,
        featName: "Mighty Summoner"
    },
    panSelect: {
        enablePan: false,
        enableSelect: false,
        panGM: {
            none: "None",
            npc: "NPC",
            all: "All"
        },
        panPlayers: {
            none: "None",
            owner: "Owner",
            observer: "Observer",
            all: "All"
        },
        selectGM: false,
        selectPlayers: false,
        observerDeselect: false,
    },
    rerollInitiative: {
        enable: false,
        rerollTempCombatants: false
    },
    tempCombatants: {
        enable: false
    },
    actorUtility: {
        initiativeFromSheet: false
    },
    tokenUtility: {
        autoRollHP: false,
        hideAutoRoll: false,
        effectSize: {
            xLarge: {
                multiplier: 5,
                divisor: 2
            },
            large: {
                multiplier: 3.3,
                divisor: 3
            },
            medium: {
                multiplier: 2.5,
                divisor: 4
            },
            small: {
                multiplier: 2,
                divisor: 5
            }
        },
        effectSizeChoices: {
            "small": "Small (Default) - 5x5",
            "medium": "Medium - 4x4",
            "large": "Large - 3x3",
            "xLarge": "Extra Large - 2x2"
        }
    },
    trackerUtility: {
        enableGiveXP: false,
    },
    triggler: {
        form: {
            title: "Triggler"
        },
        flags: {
            macro: "macroTrigger"
        },
        operators: {
            eq: "=",
            lt: "<",
            ne: "!=",
            lteq: "<=",
            gt: ">",
            gteq: ">="
        },
        options: {
            percent: "%"
        },
        templatePaths: {
            macroTriggerSelect: `${PATH}/templates/trigger-select.html`
        }
        
    }
}

export const FLAGS = {
    concentrator: {
        chatMessage: "concentratorChatMessageParsed",
        damageTaken: "damageWasTaken",
        damageAmount: "damageAmount",
        isDead: "isDead"
    },
    enhancedConditions: {
        conditionId: "conditionId",
        overlay: "overlay"
    },
    giveXP: {
        deselectByDefault: "deselectByDefault"
    },
    mightySummoner: {
        mightySummoner: "mightySummoner"
    },
    temporaryCombatants: {
        temporaryCombatant: "temporaryCombatant"
    },
    hideNames: {
        enable: "enableHideName",
        replacementType: "hideNameReplacementType",
        replacementName: "hideNameReplacement"
    }
}

export const SETTING_KEYS = {
    aboutApp: {
        menu: "aboutApp"
    },
    concentrator: {
        enable: "enableConcentrator",
        conditionName: "concentratorConditionName",
        outputChat: "concentratorOutputToChat",
        autoConcentrate: "autoConcentrate",
        concentrationAttribute: "concentrationAttribute",
        notifyDouble: "notifyDoubleConcentration",
        healthAttribute: "concentratorHealthAttribute", //validate necessity
        prompt: "concentratorPromptPlayer"
    },
    cubPuter: {
        menu: "cubPuter",
        config: "cubPuterConfig"
    },
    enhancedConditions: {
        enable: "enableEnhancedConditions",
        coreIcons: "coreStatusIcons",
        coreEffects: "coreStatusEffects",
        system: "activeSystem",
        map: "activeConditionMap",
        defaultMaps: "defaultConditionMaps",
        mapType: "conditionMapType",
        removeDefaultEffects: "removeDefaultEffects",
        outputChat: "conditionsOutputToChat",
        outputCombat: "conditionsOutputDuringCombat",
        suppressPreventativeSaveReminder: "conditionsSuppressPreventativeSaveReminder"
    },
    giveXP: {
        enable: "enableGiveXP",
        modifier: "giveXpModifier"
    },
    hideNames: {
        enable: "enableHideNPCNames",
        enableHostile: "enableHideHostileNames",
        enableNeutral: "enableHideNeutralNames",
        enableFriendly: "enableHideFriendlyNames",
        hostileNameReplacement: "hostileNameReplacement",
        neutralNameReplacement: "neutralNameReplacement",
        friendlyNameReplacement: "friendlyNameReplacement",
        hideFooter: "hideFooter",
        hideParts: "hideNameParts"
    },
    mightySummoner: {
        enable: "enableMightySummoner",
        featName: "mightySummonerFeatName"
    },
    panSelect: {
        enablePan: "enablePan",
        panGM: "panGM",
        panPlayers: "panPlayers",
        enableSelect: "enableSelect",
        selectGM: "selectGM",
        selectPlayers: "selectPlayers",
        observerDeselect: "observerDeselect"
    },
    rerollInitiative: {
        enable: "enableRerollInitiative",
        rerollTemp: "rerollTempCombatants"
    },
   
    tempCombatants: {
        enable: "enableTempCombatants"
    },
    actorUtility: {
        initiativeFromSheet: "initiativeFromSheet"
    },
    tokenUtility: {
        mightySummoner: "enableMightySummoner",
        mightySummonerFeat: "mightySummonerFeatName",
        autoRollHP: "autoRollHP",
        hideAutoRoll: "hideAutoRollHP",
        effectSize: "effectSize"
    },
    triggler: {
        triggers: "storedTriggers"
    }
}

