import { Signal } from "./modules/signal.js";

/**
 * Start the module
 */
Signal.lightUp();